# Yodoku 🦖

A cute Queens-style logic puzzle. Place one dino in every **row**, **column** and **colour region** —
and dinos never touch, not even diagonally. Starring **Yo**, an original chubby dinosaur.

## Play
Open `index.html` in any browser, or serve the folder (recommended, so the offline service worker and
"Add to Home Screen" work):

```bash
npx serve .          # or: python3 -m http.server 8080
```

On iPhone: open the page in Safari → Share → **Add to Home Screen**. It launches full-screen like an app,
respects the notch/home-bar safe areas, and works offline after the first visit.

## Features
- Endless generated puzzles at **Easy 6×6 · Normal 7×7 · Hard 8×8 · Ultra 9×9**, each with exactly one
  solution and solvable by pure logic (no guessing).
- **Daily** puzzle — same board for everyone each day, with streaks.
- Tap once for an X, twice for a dino, three times to clear; **drag** to paint X's; **Auto X** option.
- Mistake highlighting, logic-based **hints** that point at the next deduction, undo, clear, timer,
  best times, share card with emoji grid, sounds & haptics (all toggleable in Settings).
- Progress is saved per mode in `localStorage`, so you can switch tabs and come back.

## Files
| File | What |
|---|---|
| `index.html` | Markup, styles, and the SVG sprite for Yo (normal / happy / oops faces), egg, X mark and UI icons |
| `engine.js` | Puzzle generator, uniqueness solver, human-style logic solver (difficulty rating + hints), daily seed |
| `app.js` | Game UI: touch input, auto-X bookkeeping, undo history, timer, stats, win screen, confetti, share |
| `manifest.json`, `sw.js` | PWA manifest and offline cache |
| `icons/` | `icon.svg` source plus rendered PNGs (apple-touch-icon 180, 192, 512, maskable 512) |

## How puzzles are made (engine.js)
1. Pick a random valid dino layout (one per row/col, none touching).
2. Grow one colour region out of each dino with weighted random flood-fill.
3. If the board has more than one solution, nudge boundary cells that an alternate solution depends on
   (keeping regions connected) until it is unique.
4. Grade it with a human-style solver (singles → confined regions → region sets → one-step lookahead)
   and keep sampling until the score lands in the difficulty band. Typical generation time: a few ms.

`Yodoku.generate({ difficulty: 'hard', seed: 123 })` is deterministic, which is what makes the Daily work.
