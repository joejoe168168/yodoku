/* Yodoku — game UI. Requires engine.js (window.Yodoku). */
(function () {
  'use strict';
  const Y = window.Yodoku;
  const $ = (s, el) => (el || document).querySelector(s);
  const $$ = (s, el) => Array.from((el || document).querySelectorAll(s));

  const MODES = ['easy', 'normal', 'hard', 'ultra', 'daily'];
  const EMOJI = ['🩷', '🟧', '🟨', '🟩', '🟦', '🟪', '🩵', '⬜', '🟥'];
  const LS = {
    get(k, d) { try { const v = localStorage.getItem('yodoku.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('yodoku.' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } },
    del(k) { try { localStorage.removeItem('yodoku.' + k); } catch (e) { /* ignore */ } }
  };

  // ---------- settings & stats ----------
  const settings = Object.assign({ autoX: true, showErrors: true, sound: true, haptics: true, showTimer: true, seenHelp: false }, LS.get('settings', {}));
  const saveSettings = () => LS.set('settings', settings);
  const stats = LS.get('stats', {});
  for (const m of MODES) stats[m] = Object.assign({ solved: 0, best: null, streak: 0, lastDate: null }, stats[m] || {});
  const saveStats = () => LS.set('stats', stats);

  // ---------- date helpers ----------
  const pad = n => String(n).padStart(2, '0');
  const isoDate = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const today = () => isoDate(new Date());
  const yesterday = () => { const d = new Date(); d.setDate(d.getDate() - 1); return isoDate(d); };
  const fmtTime = ms => { const s = Math.floor(ms / 1000); return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`; };
  const niceDate = str => new Date(str + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' });
  function currentStreak() {
    const d = stats.daily; if (!d.lastDate) return 0;
    return (d.lastDate === today() || d.lastDate === yesterday()) ? d.streak : 0;
  }

  // ---------- audio & haptics ----------
  let actx = null;
  function tone(freq, dur, type, vol, when) {
    if (!settings.sound) return;
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      if (actx.state === 'suspended') actx.resume();
      const t = actx.currentTime + (when || 0);
      const o = actx.createOscillator(), g = actx.createGain();
      o.type = type || 'sine'; o.frequency.setValueAtTime(freq, t);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.12, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + dur + 0.02);
    } catch (e) { /* no audio */ }
  }
  const sfx = {
    x: () => tone(330, 0.06, 'triangle', 0.08),
    clear: () => tone(240, 0.07, 'triangle', 0.07),
    place: () => { tone(520, 0.09, 'sine', 0.12); tone(780, 0.14, 'sine', 0.12, 0.07); },
    error: () => tone(140, 0.18, 'square', 0.05),
    hint: () => { tone(660, 0.08, 'sine', 0.08); tone(880, 0.12, 'sine', 0.08, 0.09); },
    win: () => [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.22, 'sine', 0.12, i * 0.11))
  };
  const buzz = ms => { if (settings.haptics && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) { /* ignore */ } } };

  // ---------- toast ----------
  const toastEl = $('#toast'); let toastTimer = 0;
  function toast(msg, ms) {
    toastEl.textContent = msg; toastEl.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => toastEl.classList.remove('show'), ms || 2200);
  }

  // ---------- game state ----------
  let mode = LS.get('mode', 'normal'); if (!MODES.includes(mode)) mode = 'normal';
  let game = null;  // { puzzle, cells, autoOwner, history, elapsed, running, startedAt, hints, solved, seed, dateStr, colors }
  const board = $('#board'), linesEl = $('#lines');
  let cellEls = [];

  function newSeed() {
    if (window.crypto && crypto.getRandomValues) { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0]; }
    return (Math.random() * 4294967296) >>> 0;
  }

  function makeGame(puzzle, extra) {
    const N = puzzle.n * puzzle.n;
    const r = Y.rng(puzzle.seed ^ 0x9E3779B9);
    const colors = Array.from({ length: puzzle.n }, (_, i) => i % 9);
    for (let i = colors.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [colors[i], colors[j]] = [colors[j], colors[i]]; }
    return Object.assign({
      puzzle, cells: new Array(N).fill(0), autoOwner: new Array(N).fill(-1), history: [],
      elapsed: 0, running: false, startedAt: 0, hints: 0, solved: false, seed: puzzle.seed, dateStr: null, colors
    }, extra || {});
  }

  function freshPuzzle(m) {
    if (m === 'daily') {
      const d = today();
      const p = Y.generate({ difficulty: Y.dailyDifficulty(d), size: Y.dailySize(d), seed: Y.dailySeed(d) });
      return makeGame(p, { dateStr: d });
    }
    return makeGame(Y.generate({ difficulty: m, seed: newSeed() }));
  }

  function saveGame() {
    if (!game) return;
    const g = game;
    LS.set('game.' + mode, { seed: g.seed, dateStr: g.dateStr, cells: g.cells, autoOwner: g.autoOwner, elapsed: currentElapsed(), hints: g.hints, solved: g.solved });
    updateTabDots();
  }
  function loadGame(m) {
    const s = LS.get('game.' + m, null);
    if (!s) return null;
    if (m === 'daily' && s.dateStr !== today()) return null;
    try {
      const p = m === 'daily'
        ? Y.generate({ difficulty: Y.dailyDifficulty(s.dateStr), size: Y.dailySize(s.dateStr), seed: Y.dailySeed(s.dateStr) })
        : Y.generate({ difficulty: m, seed: s.seed });
      if (!s.cells || s.cells.length !== p.n * p.n) return null;
      return makeGame(p, { cells: s.cells, autoOwner: s.autoOwner || new Array(p.n * p.n).fill(-1), elapsed: s.elapsed || 0, hints: s.hints || 0, solved: !!s.solved, dateStr: s.dateStr || null });
    } catch (e) { return null; }
  }

  // ---------- timer ----------
  const timerEl = $('#timer');
  function currentElapsed() { return game ? game.elapsed + (game.running ? Date.now() - game.startedAt : 0) : 0; }
  function startTimer() { if (game && !game.running && !game.solved) { game.running = true; game.startedAt = Date.now(); } }
  function pauseTimer() { if (game && game.running) { game.elapsed += Date.now() - game.startedAt; game.running = false; } }
  function renderTimer() { timerEl.textContent = fmtTime(currentElapsed()); timerEl.style.visibility = settings.showTimer ? 'visible' : 'hidden'; }
  setInterval(renderTimer, 500);
  document.addEventListener('visibilitychange', () => { if (document.hidden) { pauseTimer(); saveGame(); } else if (game && !game.solved && game.history.length) startTimer(); });
  window.addEventListener('pagehide', () => { pauseTimer(); saveGame(); });

  // ---------- rendering ----------
  function buildBoard() {
    const { n, region } = game.puzzle;
    board.style.setProperty('--n', n);
    board.classList.toggle('won', game.solved);
    $$('.cell', board).forEach(el => el.remove());
    cellEls = [];
    const frag = document.createDocumentFragment();
    for (let i = 0; i < n * n; i++) {
      const el = document.createElement('div');
      el.className = 'cell'; el.dataset.i = i; el.setAttribute('role', 'gridcell');
      el.style.background = `var(--c${game.colors[region[i]]})`;
      frag.appendChild(el); cellEls.push(el);
    }
    board.insertBefore(frag, linesEl);
    // region borders
    let d1 = '', d2 = '';
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const i = y * n + x;
      if (x < n - 1) { const seg = `M${x + 1} ${y}v1`; if (region[i] !== region[i + 1]) d2 += seg; else d1 += seg; }
      if (y < n - 1) { const seg = `M${x} ${y + 1}h1`; if (region[i] !== region[i + n]) d2 += seg; else d1 += seg; }
    }
    linesEl.setAttribute('viewBox', `0 0 ${n} ${n}`);
    linesEl.innerHTML = `<path class="thin" d="${d1}"/><path class="thick" d="${d2}"/>`;
    for (let i = 0; i < n * n; i++) renderCell(i, false);
    renderErrors();
    renderLabels();
  }

  function renderCell(i, animate) {
    const el = cellEls[i], v = game.cells[i];
    const want = v === 0 ? '' : v === 1 ? 'x' : 'dino';
    if (el.dataset.v === want && !animate) return;
    el.dataset.v = want;
    el.setAttribute('aria-label', v === 0 ? 'empty' : v === 1 ? 'crossed out' : 'dino');
    if (v === 0) el.innerHTML = '';
    else if (v === 1) el.innerHTML = `<div class="x${animate ? ' pop' : ''}"><svg><use href="#xmark"/></svg></div>`;
    else el.innerHTML = `<div class="dino${animate ? ' pop' : ''}"><svg><use href="#yo"/></svg></div>`;
  }

  function renderErrors() {
    const { n, region } = game.puzzle;
    const bad = settings.showErrors ? Y.conflicts(n, region, game.cells).bad : new Set();
    for (let i = 0; i < cellEls.length; i++) {
      const el = cellEls[i], isBad = bad.has(i);
      if (el.classList.contains('err') !== isBad) {
        el.classList.toggle('err', isBad);
        const use = el.querySelector('.dino use'); if (use) use.setAttribute('href', isBad ? '#yo-oops' : '#yo');
      }
    }
    return bad.size;
  }

  function renderLabels() {
    const n = game.puzzle.n;
    const lbl = $('#levelLabel');
    if (mode === 'daily') {
      const streak = currentStreak();
      lbl.innerHTML = `<b>Daily</b> · ${niceDate(game.dateStr)} · ${n}×${n}` + (streak ? ` <span class="streak-flame"><svg width="14" height="14" style="display:inline;vertical-align:-2px"><use href="#i-flame"/></svg>${streak}</span>` : '');
    } else {
      lbl.innerHTML = `<b>Level ${stats[mode].solved + (game.solved ? 0 : 1)}</b> · ${n}×${n}`;
    }
    $('#btnUndo').disabled = game.history.length === 0 || game.solved;
    $('#btnHint').disabled = game.solved;
    $('#btnClear').disabled = game.solved;
    const nextBtn = $('#btnNew');
    if (mode === 'daily') {
      nextBtn.innerHTML = game.solved ? '<svg><use href="#i-share"/></svg>Share' : '<svg><use href="#i-next"/></svg>Skip';
      nextBtn.disabled = false;
    } else {
      nextBtn.innerHTML = game.solved ? '<svg><use href="#i-next"/></svg>Next' : '<svg><use href="#i-next"/></svg>New';
    }
    renderTimer();
  }

  function updateTabDots() {
    for (const t of $$('.tab')) {
      const m = t.dataset.mode, s = LS.get('game.' + m, null);
      const live = s && !s.solved && s.cells && s.cells.some(v => v !== 0) && (m !== 'daily' || s.dateStr === today());
      t.classList.toggle('has-progress', !!live);
      t.setAttribute('aria-selected', m === mode ? 'true' : 'false');
    }
  }

  // ---------- moves ----------
  function snapshot() { game.history.push({ cells: game.cells.slice(), autoOwner: game.autoOwner.slice() }); if (game.history.length > 200) game.history.shift(); }

  function applyAutoX(i) {
    const { n, region } = game.puzzle;
    for (const j of Y.coverage(n, region, i)) if (game.cells[j] === 0) { game.cells[j] = 1; game.autoOwner[j] = i; }
  }
  function removeAutoX(i) {
    const { n, region } = game.puzzle, N = n * n;
    const dinos = []; for (let d = 0; d < N; d++) if (game.cells[d] === 2 && d !== i) dinos.push(d);
    const cov = dinos.map(d => Y.coverage(n, region, d));
    for (let j = 0; j < N; j++) {
      if (game.autoOwner[j] !== i) continue;
      const k = cov.findIndex(c => c.has(j));
      if (k >= 0) game.autoOwner[j] = dinos[k]; else { game.cells[j] = 0; game.autoOwner[j] = -1; }
    }
  }

  // set one cell to a value, handling auto-X bookkeeping. Returns true if changed.
  function setCell(i, v) {
    const cur = game.cells[i]; if (cur === v) return false;
    if (cur === 2) removeAutoX(i);
    game.cells[i] = v; game.autoOwner[i] = -1;
    if (v === 2 && settings.autoX) applyAutoX(i);
    return true;
  }

  function afterMove(changed, animateIdx) {
    for (let i = 0; i < cellEls.length; i++) renderCell(i, i === animateIdx);
    const bad = renderErrors();
    if (bad && changed && settings.showErrors) { sfx.error(); buzz([30, 40, 30]); }
    startTimer();
    checkWin();
    renderLabels();
    saveGame();
  }

  function tapCell(i) {
    if (game.solved) return;
    clearHints();
    const cur = game.cells[i], next = (cur + 1) % 3;
    snapshot();
    setCell(i, next);
    if (next === 1) { sfx.x(); buzz(8); } else if (next === 2) { sfx.place(); buzz(15); } else { sfx.clear(); buzz(8); }
    afterMove(true, i);
  }

  // drag painting
  let drag = null; // { down:i, moved:false, mode:'x'|'clear'|null, touched:Set, snapshotTaken }
  function cellFromPoint(x, y) {
    const r = board.getBoundingClientRect(), n = game.puzzle.n;
    const cx = Math.floor((x - r.left) / r.width * n), cy = Math.floor((y - r.top) / r.height * n);
    if (cx < 0 || cy < 0 || cx >= n || cy >= n) return -1;
    return cy * n + cx;
  }
  board.addEventListener('pointerdown', e => {
    if (!game || game.solved || e.button > 0) return;
    const i = cellFromPoint(e.clientX, e.clientY); if (i < 0) return;
    drag = { down: i, moved: false, mode: null, touched: new Set([i]), pid: e.pointerId };
    try { board.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    cellEls[i].classList.add('press');
    e.preventDefault();
  });
  board.addEventListener('pointermove', e => {
    if (!drag || e.pointerId !== drag.pid) return;
    const i = cellFromPoint(e.clientX, e.clientY);
    if (i < 0 || drag.touched.has(i)) return;
    if (!drag.moved) {
      drag.moved = true; clearHints();
      cellEls[drag.down].classList.remove('press');
      const v0 = game.cells[drag.down];
      drag.mode = v0 === 0 ? 'x' : v0 === 1 ? 'clear' : null;
      if (drag.mode) { snapshot(); paint(drag.down); }
    }
    drag.touched.add(i);
    if (drag.mode) paint(i);
  });
  function paint(i) {
    const v = game.cells[i];
    if (drag.mode === 'x' && v === 0) { game.cells[i] = 1; game.autoOwner[i] = -1; renderCell(i, true); sfx.x(); }
    else if (drag.mode === 'clear' && v === 1) { game.cells[i] = 0; game.autoOwner[i] = -1; renderCell(i, true); sfx.clear(); }
    else return;
    buzz(5);
  }
  function endDrag(e) {
    if (!drag || (e && e.pointerId !== drag.pid)) return;
    const d = drag; drag = null;
    cellEls[d.down].classList.remove('press');
    if (!d.moved) { if (e && e.type !== 'pointercancel') tapCell(d.down); return; }
    if (d.mode) afterMove(true, -1);
  }
  board.addEventListener('pointerup', endDrag);
  board.addEventListener('pointercancel', endDrag);
  board.addEventListener('lostpointercapture', () => { if (drag && drag.moved) endDrag({ pointerId: drag.pid, type: 'pointerup' }); });
  board.addEventListener('contextmenu', e => e.preventDefault());

  // ---------- hints ----------
  let hintTimer = 0;
  function clearHints() { for (const el of cellEls) el.classList.remove('hint', 'hint-focus'); clearTimeout(hintTimer); }
  function showHint() {
    if (!game || game.solved) return;
    clearHints();
    const h = Y.hint(game.puzzle, game.cells);
    for (const i of h.cells || []) cellEls[i].classList.add('hint');
    for (const i of h.focus || []) if (i !== null && i !== undefined) cellEls[i].classList.add('hint-focus');
    if (h.kind === 'wrong' || h.kind === 'badx') for (const i of h.cells) cellEls[i].classList.add('hint-focus');
    game.hints++; sfx.hint(); buzz(10);
    toast(h.msg, 3200);
    startTimer();
    hintTimer = setTimeout(clearHints, 3500);
    saveGame();
  }

  // ---------- win ----------
  function checkWin() {
    const { n, region } = game.puzzle;
    if (game.solved || !Y.isSolved(n, region, game.cells)) return;
    game.solved = true; pauseTimer();
    const t = currentElapsed(), s = stats[mode];
    s.solved++;
    const isBest = s.best === null || t < s.best; if (isBest) s.best = t;
    if (mode === 'daily') {
      if (s.lastDate === yesterday()) s.streak++; else if (s.lastDate !== today()) s.streak = 1;
      s.lastDate = today();
    }
    saveStats(); saveGame();
    board.classList.add('won');
    for (const el of cellEls) el.classList.remove('err');
    // wave of happy dinos
    $$('.dino', board).forEach((d, k) => { setTimeout(() => { d.classList.remove('pop'); void d.offsetWidth; d.classList.add('pop'); d.querySelector('use').setAttribute('href', '#yo-happy'); }, k * 70); });
    sfx.win(); buzz([20, 60, 20, 60, 40]);
    confetti();
    setTimeout(() => openWin(t, isBest), 900);
  }

  function emojiGrid() {
    const { n, region } = game.puzzle; let out = '';
    for (let y = 0; y < n; y++) { for (let x = 0; x < n; x++) { const i = y * n + x; out += game.cells[i] === 2 ? '🦖' : EMOJI[game.colors[region[i]]]; } out += '\n'; }
    return out;
  }
  function shareText() {
    const t = fmtTime(currentElapsed()), n = game.puzzle.n;
    const head = mode === 'daily' ? `Yodoku Daily ${game.dateStr} (${n}×${n})` : `Yodoku ${Y.DIFFS[mode].label} · Level ${stats[mode].solved} (${n}×${n})`;
    const streak = mode === 'daily' && currentStreak() > 1 ? ` · 🔥 ${currentStreak()}` : '';
    return `${head}\n⏱ ${t} · 💡 ${game.hints} hint${game.hints === 1 ? '' : 's'}${streak}\n${emojiGrid()}${location.href.split('#')[0]}`;
  }
  async function share() {
    const text = shareText();
    try { if (navigator.share) { await navigator.share({ text }); return; } } catch (e) { if (e && e.name === 'AbortError') return; }
    try { await navigator.clipboard.writeText(text); toast('Copied to clipboard!'); } catch (e) { toast('Sharing not available here'); }
  }

  function openWin(t, isBest) {
    $('#winTime').textContent = fmtTime(t);
    $('#winBest').textContent = stats[mode].best !== null ? fmtTime(stats[mode].best) : '—';
    $('#winHints').textContent = game.hints;
    const subs = ['Every dino found a home.', 'Roar-some logic!', 'Not a single dino was squished.', 'Dino-mite solving!', 'Clean and cosy — no neighbours.'];
    let sub = subs[(game.seed >>> 3) % subs.length];
    if (isBest && stats[mode].solved > 1) sub = '🏆 New best time!';
    if (mode === 'daily' && currentStreak() > 1) sub += ` 🔥 ${currentStreak()}-day streak!`;
    $('#winSub').textContent = sub;
    $('#winGrid').textContent = emojiGrid();
    $('#btnWinNext').innerHTML = mode === 'daily' ? '<svg width="22" height="22"><use href="#i-next"/></svg>Play more' : '<svg width="22" height="22"><use href="#i-next"/></svg>Next puzzle';
    openModal('#winModal');
  }

  // ---------- confetti ----------
  function confetti() {
    const cv = $('#confetti'), ctx = cv.getContext('2d');
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = innerWidth * dpr; cv.height = innerHeight * dpr; ctx.scale(dpr, dpr);
    cv.classList.remove('hidden');
    const colors = ['#6FCB73', '#FF9F6E', '#FF9BB1', '#FFD24D', '#8FD3FF', '#D4BFFF'];
    const parts = Array.from({ length: 140 }, () => ({
      x: innerWidth / 2 + (Math.random() - .5) * innerWidth * .6, y: innerHeight * .45,
      vx: (Math.random() - .5) * 14, vy: -Math.random() * 16 - 6, r: 4 + Math.random() * 6,
      c: colors[(Math.random() * colors.length) | 0], rot: Math.random() * 6.28, vr: (Math.random() - .5) * .3, egg: Math.random() < .3
    }));
    const t0 = performance.now();
    function frame(t) {
      const dt = (t - t0) / 1000; ctx.clearRect(0, 0, innerWidth, innerHeight);
      for (const p of parts) {
        p.x += p.vx; p.y += p.vy; p.vy += .45; p.vx *= .99; p.rot += p.vr;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.fillStyle = p.c; ctx.globalAlpha = Math.max(0, 1 - Math.max(0, dt - 1.6));
        if (p.egg) { ctx.beginPath(); ctx.ellipse(0, 0, p.r * .8, p.r, 0, 0, 6.29); ctx.fill(); } else ctx.fillRect(-p.r / 2, -p.r / 3, p.r, p.r * .66);
        ctx.restore();
      }
      if (dt < 2.6) requestAnimationFrame(frame); else { cv.classList.add('hidden'); ctx.clearRect(0, 0, innerWidth, innerHeight); }
    }
    requestAnimationFrame(frame);
  }

  // ---------- modals ----------
  function openModal(sel) { $(sel).classList.add('open'); }
  function closeModal(sel) { $(sel).classList.remove('open'); }
  for (const s of $$('.scrim')) s.addEventListener('click', e => { if (e.target === s) closeModal('#' + s.id); });
  $('#btnHelp').addEventListener('click', () => openModal('#helpModal'));
  $('#btnHelpClose').addEventListener('click', () => { closeModal('#helpModal'); settings.seenHelp = true; saveSettings(); });
  $('#btnSettings').addEventListener('click', () => { renderStats(); openModal('#settingsModal'); });
  $('#btnSettingsClose').addEventListener('click', () => closeModal('#settingsModal'));
  $('#btnShare').addEventListener('click', share);
  $('#btnWinNext').addEventListener('click', () => { closeModal('#winModal'); if (mode === 'daily') switchMode(stats.normal.solved > 3 ? 'hard' : 'normal'); else startNew(); });
  for (const sw of $$('.switch')) {
    const k = sw.dataset.setting; sw.setAttribute('aria-checked', settings[k] ? 'true' : 'false');
    sw.addEventListener('click', () => {
      settings[k] = !settings[k]; sw.setAttribute('aria-checked', settings[k] ? 'true' : 'false'); saveSettings();
      if (k === 'showErrors' && game) renderErrors();
      if (k === 'showTimer') renderTimer();
      buzz(6);
    });
  }
  function renderStats() {
    const g = $('#statGrid'); g.innerHTML = '';
    for (const m of MODES) {
      const s = stats[m], label = m === 'daily' ? 'Daily' : Y.DIFFS[m].label;
      const extra = m === 'daily' ? ` · 🔥 ${currentStreak()}` : '';
      g.insertAdjacentHTML('beforeend', `<div class="stat"><b>${s.solved}</b><span>${label} solved${extra}<br>best ${s.best !== null ? fmtTime(s.best) : '—'}</span></div>`);
    }
  }

  // ---------- controls ----------
  $('#btnUndo').addEventListener('click', () => {
    if (!game || game.solved || !game.history.length) return;
    clearHints();
    const h = game.history.pop(); game.cells = h.cells; game.autoOwner = h.autoOwner;
    sfx.clear(); buzz(8);
    for (let i = 0; i < cellEls.length; i++) renderCell(i, false);
    renderErrors(); renderLabels(); saveGame();
  });
  $('#btnHint').addEventListener('click', showHint);
  $('#btnClear').addEventListener('click', () => {
    if (!game || game.solved) return;
    if (!game.cells.some(v => v)) return;
    clearHints(); snapshot();
    game.cells.fill(0); game.autoOwner.fill(-1);
    sfx.clear(); buzz(12);
    for (let i = 0; i < cellEls.length; i++) renderCell(i, false);
    renderErrors(); renderLabels(); saveGame();
    toast('Board cleared — Undo brings it back');
  });
  let newArmed = 0;
  $('#btnNew').addEventListener('click', () => {
    if (!game) return;
    if (mode === 'daily') {
      if (game.solved) { share(); return; }
      if (Date.now() - newArmed > 2500) { newArmed = Date.now(); toast('There\'s one Daily per day. Tap again to hop to Normal instead.'); return; }
      switchMode('normal'); return;
    }
    if (!game.solved && game.cells.some(v => v)) {
      if (Date.now() - newArmed > 2500) { newArmed = Date.now(); toast('Tap New again to skip this puzzle'); return; }
    }
    startNew();
  });

  function startNew() {
    clearHints(); closeModal('#winModal');
    game = freshPuzzle(mode);
    buildBoard(); saveGame();
    board.animate([{ transform: 'scale(.94)', opacity: .4 }, { transform: 'scale(1)', opacity: 1 }], { duration: 260, easing: 'cubic-bezier(.2,.9,.3,1.2)' });
  }

  function switchMode(m) {
    if (game) { pauseTimer(); saveGame(); }
    mode = m; LS.set('mode', m);
    clearHints(); closeModal('#winModal');
    game = loadGame(m) || freshPuzzle(m);
    if (game.solved && m !== 'daily') { game = freshPuzzle(m); }
    buildBoard(); updateTabDots(); saveGame();
  }
  for (const t of $$('.tab')) t.addEventListener('click', () => { if (t.dataset.mode !== mode) { buzz(6); switchMode(t.dataset.mode); } });

  // keyboard (desktop convenience)
  document.addEventListener('keydown', e => {
    if (e.key === 'z' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); $('#btnUndo').click(); }
    if (e.key === 'h') showHint();
    if (e.key === 'Escape') for (const s of $$('.scrim.open')) closeModal('#' + s.id);
  });

  // ---------- boot ----------
  switchMode(mode);
  if (!settings.seenHelp) setTimeout(() => openModal('#helpModal'), 400);
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => { /* offline support unavailable */ }));
  }
})();
